package com.example.a4;

import android.os.Parcel;
import android.os.Parcelable;

public class WeatherData implements Parcelable {

    private String city;
    private int currentTemperature;
    private int TomorrowcurrentTemperature;
    private int highTemperature;
    private  int TomorrowhighTemperature;
    private int lowTemperature;
    private  int TomorrowlowTemperature;
    private String description;
    private  String Tomorrowdescription;

    public WeatherData(String city,
                       int currentTemperature,
                       int TomorrowcurrentTemperature,
                       int highTemperature,
                       int TomorrowhighTemperature,
                       int lowTemperature,
                       int TomorrowlowTemperature,
                       String description,
                        String Tomorrowdescription)
    {
        this.city = city;
        this.currentTemperature = currentTemperature;
        this.TomorrowcurrentTemperature = TomorrowcurrentTemperature;
        this.description = description;
        this.Tomorrowdescription = Tomorrowdescription;
        this.highTemperature = highTemperature;
        this.TomorrowhighTemperature = TomorrowhighTemperature;
        this.lowTemperature = lowTemperature;
        this.TomorrowlowTemperature = TomorrowlowTemperature;
    }

    public WeatherData(Parcel in){
        this(in.readString(),in.readInt(),in.readInt(),in.readInt(),in.readInt(),in.readInt(),in.readInt(),in.readString(),in.readString());
    }

    public static final Creator<WeatherData> CREATOR = new Creator<WeatherData>() {
        @Override
        public WeatherData createFromParcel(Parcel in) {
            return new WeatherData(in);
        }

        @Override
        public WeatherData[] newArray(int size) {
            return new WeatherData[size];
        }
    };

    public String getCity(){
        return city;
    }

    public  String getDescription(){
        return description;
    }

    public  String getTomorrowDescription(){
        return Tomorrowdescription;
    }

    public int getCurrentTemperature(){
        return currentTemperature;
    }

    public int getTomorrowCurrentTemperature(){
        return TomorrowcurrentTemperature;
    }

    public int getHighTemperature(){
        return highTemperature;
    }
    public int getTomorrowHighTemperature(){
        return TomorrowhighTemperature;
    }

    public int getLowTemperature(){
        return lowTemperature;
    }
    public int getTomorrowLowTemperature(){
        return TomorrowlowTemperature;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(getCity());

        dest.writeInt(getCurrentTemperature());
        dest.writeInt(getHighTemperature());
        dest.writeInt(getLowTemperature());
        dest.writeString(getDescription());
        dest.writeInt(getTomorrowCurrentTemperature());
        dest.writeInt(getTomorrowHighTemperature());
        dest.writeInt(getTomorrowLowTemperature());
        dest.writeString(getTomorrowDescription());
    }
}
