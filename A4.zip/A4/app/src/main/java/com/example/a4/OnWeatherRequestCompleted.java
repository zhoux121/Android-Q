package com.example.a4;

public interface OnWeatherRequestCompleted {
    void onWeatherCompleted(WeatherData data);
}
