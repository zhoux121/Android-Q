package com.example.a4;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

public class WeatherDetails extends Fragment {
    public WeatherDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        WeatherData data = getArguments().getParcelable(MainActivity.WEATHER_KEY);

        View view = inflater.inflate(R.layout.fragment_weather_details, container, false);
        TextView cityTextView = view.findViewById(R.id.cityTextView);
        TextView currentTemperatureTextView = view.findViewById(R.id.currentTemperatureTextView);
        TextView highTemperatureTextView = view.findViewById(R.id.highTemperatureTextView);
        TextView lowTemperatureTextView = view.findViewById(R.id.lowTemperatureTextView);
        TextView descriptionTextView = view.findViewById(R.id.weatherDescriptionTextView);
        TextView TomorrowcurrentTemperatureTextView = view.findViewById(R.id.Tomorrow_currentTemperatureTextView);
        TextView TomorrowhighTemperatureTextView = view.findViewById(R.id.Tomorrow_highTemperatureTextView);
        TextView TomorrowlowTemperatureTextView = view.findViewById(R.id.Tomorrow_lowTemperatureTextView);
        TextView TomorrowdescriptionTextView = view.findViewById(R.id.Tomorrow_weatherDescriptionTextView);



        if(data != null){
            cityTextView.setText(data.getCity());

            currentTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getCurrentTemperature()));

            TomorrowcurrentTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getCurrentTemperature()));




            highTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getHighTemperature()));

            TomorrowhighTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getHighTemperature()));

            lowTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getLowTemperature()));

            TomorrowlowTemperatureTextView.setText(String.format(getResources().getString(R.string.temperature_celsius),
                    data.getLowTemperature()));

            descriptionTextView.setText(data.getDescription());

            TomorrowdescriptionTextView.setText(data.getDescription());
        }

        return view;


    }

}
