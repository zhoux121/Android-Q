package com.example.a4;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.ShareActionProvider;

public class AppDataManager {
    private SharedPreferences sharedPreferences;
    private static final String CITY_KEY = "city";
    private  static final String APP_KEY = "WeatherViewer";

    public AppDataManager(Context context){
        sharedPreferences = context.getSharedPreferences(APP_KEY, Context.MODE_PRIVATE);
    }
    public String getCityKey(){
        String city = sharedPreferences.getString(CITY_KEY,"");
        return city;
    }

    public  void saveCity(String city){
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.clear();
        edit.putString(CITY_KEY, city);
        edit.apply();
    }
}
