package com.example.a4;

public class ApiException extends  Exception{
    public ApiException(String message){
        super(message);
    }
}
